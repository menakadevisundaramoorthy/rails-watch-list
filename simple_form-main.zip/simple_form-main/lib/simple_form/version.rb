# frozen_string_literal: true
module SimpleForm
  VERSION = "5.1.0".freeze
end
